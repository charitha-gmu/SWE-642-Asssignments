package com.example.studentsurvey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSurveyApplicationTests {

	@Test
	void contextLoads() {
	}

}
